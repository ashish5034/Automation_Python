import os
import hashlib
import time
from datetime import datetime
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from sys import *

# def deleteDuplicateFiles(dups):
#     for path in dups:
#         os.remove(path)

def hashfile(path, blocksize=1024):
    fd = open(path, 'rb')
    hasher = hashlib.md5()
    buf = fd.read(blocksize)

    while len(buf) > 0:
        hasher.update(buf)
        buf = fd.read(blocksize)
    fd.close()
    return hasher.hexdigest()

def findDuplicatefile(directory_path):
    flag = os.path.isabs(directory_path)

    if flag == False:
        directory_path = os.path.abspath(directory_path)

    exists = os.path.isdir(directory_path)

    filechecksum = {}
    dups = []

    if exists:
        for dirname, subdirname, filenames in os.walk(directory_path):
            for filename in filenames:
                file_path = os.path.join(dirname, filename)
                file_hash = hashfile(file_path)

                if file_hash in filechecksum:
                    dups.append(file_path)
                else:
                    filechecksum[file_hash] = [file_path]
        return dups
    else:
        print("Invalid Path")

def write_to_log_file(dups):
    """
    Write the names of duplicate files to a log file with the current date and time in the filename.

    :param dups: List of duplicate file paths.
    """
    if not dups:
        print("No duplicate files found.")
        return

    current_datetime = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_filename = f"log_{current_datetime}.txt"

    with open(log_filename, "w") as log_file:
        log_file.write("Duplicate Files:\n")
        for path in dups:
            log_file.write(path + "\n")

    return log_filename

def send_email(to_email, log_filename, start_time, total_files_scanned, total_duplicates_found):
    # Email configuration
    from_email = "your_email@gmail.com"  # Replace with your email address
    password = "your_password"  # Replace with your email password
    smtp_server = "smtp.gmail.com"  # Replace with your SMTP server (for Gmail, use smtp.gmail.com)
    smtp_port = 587  # SMTP port for Gmail

    # Create a MIME object for the email
    msg = MIMEMultipart()
    msg['From'] = from_email
    msg['To'] = to_email
    msg['Subject'] = "Duplicate File Removal Report"

    # Email body
    body = f"Start time of scanning: {start_time}\nTotal number of files scanned: {total_files_scanned}\nTotal number of duplicate files found: {total_duplicates_found}"
    msg.attach(MIMEText(body, 'plain'))

    # Attach the log file
    attachment = open(log_filename, "rb")
    part = MIMEBase('application', 'octet-stream')
    part.set_payload((attachment).read())
    encoders.encode_base64(part)
    part.add_header('Content-Disposition', "attachment; filename= %s" % log_filename)
    msg.attach(part)

    # Connect to the SMTP server and send the email
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()
    server.login(from_email, password)
    text = msg.as_string()
    server.sendmail(from_email, to_email, text)
    server.quit()

def main():
    print("Duplicate file detector:")
    print("Application name:", argv[0])

    if len(argv) != 2:
        print("Invalid Number of Arguments:")
        exit()

    if argv[1] == "-h" or argv[1] == "-H":
        print("Application for showing duplicate files in a log")
        exit()

    if argv[1] == "-u" or argv[1] == "-U":
        print("Directoryname.py Demo")
        exit()

    try:
        duration_minutes = int(input("Enter duration in minutes: "))
        if duration_minutes <= 0:
            print("Invalid duration. Please enter a positive number of minutes.")
            exit()

        to_email = input("Enter your email address: ")
        if not to_email:
            print("Email address cannot be empty.")
            exit()

        while True:
            starttime = time.strftime("%Y-%m-%d %H:%M:%S")
            print("Start time is: ", starttime)
            dups = findDuplicatefile(argv[1])
            # deleteDuplicateFiles(dups)
            log_filename = write_to_log_file(dups)
            total_files_scanned = len(dups)
            total_duplicates_found = len(dups)
            
            send_email(to_email, log_filename, starttime, total_files_scanned, total_duplicates_found)

            endtime = time.strftime("%Y-%m-%d %H:%M:%S")
            print("End time is: ", endtime)
            print("Duplicate file names have been written to 'log.txt' in the current directory.")
            print('Took %s seconds to evaluate.' % (endtime - starttime))
            
            print(f"Waiting for {duration_minutes} minutes before checking again...")
            time.sleep(duration_minutes * 60)  # Convert minutes to seconds

    except ValueError:
        print("Error: Invalid data type of input")

    except Exception as E:
        print("Error: Invalid Input", E)

if __name__ == "__main__":
    main()